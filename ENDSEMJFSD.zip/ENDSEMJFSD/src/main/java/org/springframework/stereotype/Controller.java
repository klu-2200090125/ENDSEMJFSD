package org.springframework.stereotype;

public class Controller {

}
