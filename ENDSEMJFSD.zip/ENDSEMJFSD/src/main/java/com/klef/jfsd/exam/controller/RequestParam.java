package com.klef.jfsd.exam.controller;

public @interface RequestParam {

}
