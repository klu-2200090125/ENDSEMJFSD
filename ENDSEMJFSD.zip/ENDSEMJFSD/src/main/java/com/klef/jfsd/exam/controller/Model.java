package com.klef.jfsd.exam.controller;

public class Model {

	public void addAttribute(String string, int sum) {
		// TODO Auto-generated method stub
		
	}

}
