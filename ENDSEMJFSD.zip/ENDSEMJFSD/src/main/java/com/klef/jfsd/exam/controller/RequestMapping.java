package com.klef.jfsd.exam.controller;

public @interface RequestMapping {

	String value();


}
